#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

unsigned int char2int(char c) {
	
	return (c - '0');
}

int mi_atoi(char *s) {

	if (s != NULL) {
	
		int suma = 0;
		int i;
		for (;i<strlen(s);i++) {

			suma *= 10;
			suma += char2int(s[i]);
		}
		return suma;
	}
	return 0;
}

int esNumero(char *str){

	if(str != NULL){

		int i=0;
		if(str[i]=='-') ++str;
		for(; str[i]!='\0'; ++i){

			if(str[i]<'0' ||  str[i]>'9') return 0;

		}
		if (i>0 && i<= 8) return 1 ;
	}
	else return 0;
}

int main(int argc, char *argv[]){

	char buf[80];
	int suma = 0;
	for(int i=1; i<argc; i++){
		if(esNumero(argv[i])) suma += mi_atoi(argv[i]);
		else {
			sprintf(buf, "Error: el parámetro “%s” no es un número\n",argv[i]);
			write(1,buf,strlen(buf));
			exit(1);
		}
	}
	sprintf(buf, "La suma es %d\n", suma);
	write(1,buf,strlen(buf));
}
